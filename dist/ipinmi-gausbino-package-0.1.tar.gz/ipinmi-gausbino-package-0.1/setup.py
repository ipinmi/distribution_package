from setuptools import setup

setup(name='ipinmi-gausbino-package',
      version='0.1',
      description=' Binomial and Gaussian distributions',
      packages=['ipinmi-gausbino-package'],
      author="Chibundum Adebayo",
      author_email= "chibundum.adebayo@stu.cu.edu.ng",
      zip_safe=False)
